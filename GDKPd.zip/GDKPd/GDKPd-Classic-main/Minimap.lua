local addonName, addon = ...


--addon.minimapicon:Hide("GDKPdLDB")
