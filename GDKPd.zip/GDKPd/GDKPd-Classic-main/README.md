# GDKPd Classic

This is a modification of the GDKPd addon originally created by stolenlegacy

The addon has now been brought in-line with the current API (basic functionality)

Additional features are being added, additional translations are welcome. 

- poptix @ Herod



# 🤑 Note From Gogo

GDKPs have risen in popularity in Classic WoW. The most popular auctioning add-on used is GDKPd, but it hasn't been well-maintained.

I'm taking this project over for popt1x, but there are several versions of GDKPd available for download on CurseForge.

I don't have any intent to make money off of this, I just want to fix it up for the current users.

The licenses are all over the place. If you're the original license holder and you have any issues with me working on this code, please reach out.

Barring someone requesting me to take this down, I'm going to fix it up enough so it works for the people who rely on it to distribute loot.

Happy Raiding!


> GDKPdClassic; made by popt1x and last updated on 27 APR 2021 - https://www.curseforge.com/wow/addons/gdkpdclassic

> GDKPd Classic; made by elwizard0 and last updated on 29 SEP 2020 - https://www.curseforge.com/wow/addons/gdkpd-classic

> GDKPd; made by gallantron and last updated on 27 OCT 2014 - https://www.curseforge.com/wow/addons/gdkpd
